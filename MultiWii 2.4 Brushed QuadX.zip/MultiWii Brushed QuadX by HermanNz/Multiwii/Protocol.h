#ifndef PROTOCOL_H_
#define PROTOCOL_H_

void serialCom();
void debugmsg_append_str(const char *str);

#endif /* PROTOCOL_H_ */
